/**
 * PokeLeaks mod tool — Devvit Web server (Hono).
 *
 * Replaces the Reddit-facing half of the old asyncpraw bot. Every polling loop
 * from hybridasync.py is now an event trigger, and all Reddit mod actions
 * (remove / approve / comment / spoiler) happen here. The only thing still in
 * Python is the heavy image ML, reached over HTTP (see duplicate_service.py).
 *
 *   stream / modqueue duplicate workers  -> onPostSubmit  -> POST /check
 *   shared_mod_log_monitor (removelink)  -> onModAction   -> POST /mod-removed
 *   shared_removal_checker (user delete)  -> onPostDelete  -> POST /delete
 *   handle_report_thresholds              -> onPostReport / onCommentReport
 *   monitor_reported_posts (re-approve)   -> onPostReport
 *   handle_modqueue_items (1-report 1h)   -> onPostReport + scheduler one-off
 *   handle_spoiler_status                 -> onPostSpoilerUpdate
 *   wiki threshold table                  -> subreddit settings JSON
 *   invite acceptance / registry          -> gone (each sub installs the app)
 */

import { Hono } from 'hono';
import { serve } from '@hono/node-server';
import {
  createServer,
  getServerPort,
  context,
  reddit,
  redis,
  scheduler,
  settings,
  type TaskRequest,
} from '@devvit/web/server';
import type {
  OnAppInstallRequest,
  OnCommentReportRequest,
  OnModActionRequest,
  OnPostDeleteRequest,
  OnPostReportRequest,
  OnPostSpoilerUpdateRequest,
  OnPostSubmitRequest,
  SettingsValidationRequest,
  SettingsValidationResponse,
  TriggerResponse,
} from '@devvit/web/shared';

// ---------------------------------------------------------------------------
// Types for the thresholds config JSON
// ---------------------------------------------------------------------------
type RuleThresholds = {
  postRemove?: number;
  postApprove?: number;
  commentRemove?: number;
  commentApprove?: number;
};
type ThresholdConfig = Record<string, RuleThresholds>;

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
const bareId = (id: string): string => id.replace(/^t[0-9]_/, '');
const t3 = (id: string): `t3_${string}` =>
  id.startsWith('t3_') ? (id as `t3_${string}`) : `t3_${bareId(id)}`;
const t1 = (id: string): `t1_${string}` =>
  id.startsWith('t1_') ? (id as `t1_${string}`) : `t1_${bareId(id)}`;

const IMAGE_RE = /\.(jpg|jpeg|png|gif)$/i;
const isImageUrl = (url?: string): boolean => !!url && IMAGE_RE.test(url.split('?')[0]!);

async function getBool(key: string, fallback = false): Promise<boolean> {
  try {
    const v = await settings.get<boolean>(key);
    return v === undefined || v === null ? fallback : Boolean(v);
  } catch {
    return fallback;
  }
}

async function getStr(key: string): Promise<string> {
  try {
    return (await settings.get<string>(key)) ?? '';
  } catch {
    return '';
  }
}

async function getThresholds(): Promise<ThresholdConfig> {
  const raw = await getStr('reportThresholds');
  if (!raw.trim()) return {};
  try {
    const parsed = JSON.parse(raw);
    return typeof parsed === 'object' && parsed !== null ? (parsed as ThresholdConfig) : {};
  } catch {
    console.error('[config] reportThresholds is not valid JSON; ignoring');
    return {};
  }
}

/** Threshold for a specific reason + action, falling back to the "*" wildcard. */
function thresholdFor(cfg: ThresholdConfig, reason: string, action: keyof RuleThresholds): number {
  const safe = reason.replace(/\|/g, '-').trim();
  const specific = cfg[safe]?.[action];
  if (typeof specific === 'number') return specific;
  const wildcard = cfg['*']?.[action];
  return typeof wildcard === 'number' ? wildcard : 0;
}

/** Count how many reports carry each reason string. */
function countReasons(reasons: string[] | undefined): Map<string, number> {
  const counts = new Map<string, number>();
  for (const r of reasons ?? []) counts.set(r, (counts.get(r) ?? 0) + 1);
  return counts;
}

/** POST JSON to the Python duplicate-detection service. Returns null on any failure. */
async function callService(path: string, body: Record<string, unknown>): Promise<any | null> {
  const base = (await getStr('duplicateServiceUrl')).replace(/\/+$/, '');
  if (!base) {
    console.error('[service] duplicateServiceUrl is not set');
    return null;
  }
  const token = await getStr('serviceAuthToken');
  try {
    const res = await fetch(`${base}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'X-Auth-Token': token } : {}),
      },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      console.error(`[service] ${path} -> HTTP ${res.status}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error(`[service] ${path} failed:`, err);
    return null;
  }
}

function buildDuplicateComment(o: any): string {
  const author = o?.author || '[Deleted]';
  const title = o?.title || 'original post';
  const permalink = o?.permalink || '';
  const date = o?.date || '';
  const status = o?.status || 'Active';
  const titleCell = permalink ? `[${title}](${permalink})` : title;
  return [
    '> **Duplicate detected**',
    '',
    '| Original Author | Title | Date | Status |',
    '|:---------------:|:-----:|:----:|:------:|',
    `| ${author} | ${titleCell} | ${date} | ${status} |`,
  ].join('\n');
}

/** Simple TTL de-dupe so double-delivered triggers don't double-act. */
async function firstTimeSeen(key: string, ttlSeconds: number): Promise<boolean> {
  try {
    if (await redis.get(key)) return false;
    await redis.set(key, '1');
    await redis.expire(key, ttlSeconds);
    return true;
  } catch {
    return true; // never let de-dupe bookkeeping block real work
  }
}

async function clearAutoApprove(postId: string): Promise<void> {
  const key = `autoapprove:job:${t3(postId)}`;
  const jobId = await redis.get(key);
  if (jobId) {
    try {
      await scheduler.cancelJob(jobId);
    } catch {
      /* already fired or gone */
    }
    await redis.del(key);
  }
}

// ---------------------------------------------------------------------------
// Hono routers (mirrors the template's /internal structure)
// ---------------------------------------------------------------------------
const app = new Hono();
const internal = new Hono();
const triggers = new Hono();
const schedulerRoutes = new Hono();
const settingsRoutes = new Hono();

const okTrigger: TriggerResponse = { status: 'success' };

// ===========================================================================
// Duplicate detection: new post submitted  (old stream/modqueue workers)
// ===========================================================================
triggers.post('/on-post-submit', async (c) => {
  const input = await c.req.json<OnPostSubmitRequest>();
  const rawId = input.post?.id;
  if (!rawId) return c.json<TriggerResponse>(okTrigger, 200);
  const postId = t3(rawId);

  if (
    (await getBool('enableDuplicateDetection', true)) &&
    (await firstTimeSeen(`dup:seen:${postId}`, 3600))
  ) {
    const post = await reddit.getPostById(postId);
    if (isImageUrl(post.url)) {
      const verdict = await callService('/check', {
        subreddit: context.subredditName,
        submission_id: bareId(postId),
        url: post.url,
        created_utc: Math.floor(post.createdAt.getTime() / 1000),
        author: post.authorName,
        title: post.title,
        permalink: post.permalink,
      });
      if (verdict?.duplicate && !post.approved) {
        await post.remove(false);
        const comment = await post.addComment({ text: buildDuplicateComment(verdict.original) });
        await comment.distinguish(true);
        console.log(`[r/${context.subredditName}] removed duplicate (${verdict.method}): ${postId}`);
      }
    }
  }
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Report thresholds + re-approve + 1-report auto-approve timer (posts)
// ===========================================================================
triggers.post('/on-post-report', async (c) => {
  const input = await c.req.json<OnPostReportRequest>();
  const rawId = input.post?.id;
  if (!rawId) return c.json<TriggerResponse>(okTrigger, 200);
  const postId = t3(rawId);
  const post = await reddit.getPostById(postId);

  // monitor_reported_posts: keep mod-approved posts approved.
  if ((await getBool('enableReApproveReported', true)) && post.approved) {
    await post.approve();
    console.log(`[r/${context.subredditName}] re-approved reported post ${postId}`);
    return c.json<TriggerResponse>(okTrigger, 200);
  }

  // handle_report_thresholds: remove takes priority over approve.
  if (await getBool('enableReportThresholds', true)) {
    const cfg = await getThresholds();
    const counts = countReasons(post.userReportReasons);

    for (const [reason, count] of counts) {
      const th = thresholdFor(cfg, reason, 'postRemove');
      if (th > 0 && count >= th) {
        await post.remove(false);
        await clearAutoApprove(postId);
        console.log(`[r/${context.subredditName}] removed post ${postId} (${count}x "${reason}")`);
        return c.json<TriggerResponse>(okTrigger, 200);
      }
    }
    for (const [reason, count] of counts) {
      const th = thresholdFor(cfg, reason, 'postApprove');
      if (th > 0 && count >= th) {
        await post.approve();
        await clearAutoApprove(postId);
        console.log(`[r/${context.subredditName}] approved post ${postId} (${count}x "${reason}")`);
        return c.json<TriggerResponse>(okTrigger, 200);
      }
    }
  }

  // handle_modqueue_items: single-report posts auto-approve after 1h unless
  // more reports arrive in the meantime.
  if (await getBool('enableAutoApproveSingleReport', true)) {
    const total = post.numberOfReports ?? 0;
    const key = `autoapprove:job:${postId}`;
    const existing = await redis.get(key);
    if (total === 1 && !existing) {
      const jobId = await scheduler.runJob({
        name: 'auto-approve-single-report',
        data: { postId },
        runAt: new Date(Date.now() + 60 * 60 * 1000),
      });
      await redis.set(key, jobId);
      await redis.expire(key, 2 * 60 * 60);
      console.log(`[r/${context.subredditName}] armed 1h auto-approve for ${postId}`);
    } else if (total > 1 && existing) {
      await clearAutoApprove(postId);
    }
  }
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Report thresholds (comments)
// ===========================================================================
triggers.post('/on-comment-report', async (c) => {
  const input = await c.req.json<OnCommentReportRequest>();
  const rawId = input.comment?.id;
  if (!rawId || !(await getBool('enableReportThresholds', true))) {
    return c.json<TriggerResponse>(okTrigger, 200);
  }
  const comment = await reddit.getCommentById(t1(rawId));
  const cfg = await getThresholds();
  const counts = countReasons(comment.userReportReasons);

  for (const [reason, count] of counts) {
    const th = thresholdFor(cfg, reason, 'commentRemove');
    if (th > 0 && count >= th) {
      await comment.remove(false);
      console.log(`[r/${context.subredditName}] removed comment ${rawId} (${count}x "${reason}")`);
      return c.json<TriggerResponse>(okTrigger, 200);
    }
  }
  for (const [reason, count] of counts) {
    const th = thresholdFor(cfg, reason, 'commentApprove');
    if (th > 0 && count >= th) {
      await comment.approve();
      console.log(`[r/${context.subredditName}] approved comment ${rawId} (${count}x "${reason}")`);
      return c.json<TriggerResponse>(okTrigger, 200);
    }
  }
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Spoiler enforcement  (old handle_spoiler_status)
// ===========================================================================
triggers.post('/on-post-spoiler-update', async (c) => {
  const input = await c.req.json<OnPostSpoilerUpdateRequest>();
  const rawId = input.post?.id;
  if (!rawId || !(await getBool('enableSpoilerEnforcement', true))) {
    return c.json<TriggerResponse>(okTrigger, 200);
  }
  const postId = t3(rawId);

  // Our own markAsSpoiler() re-fires this trigger; short de-dupe stops a loop.
  if (await firstTimeSeen(`spoiler:seen:${postId}:${Date.now() >> 13}`, 30)) {
    const post = await reddit.getPostById(postId);
    if (!post.spoiler) {
      // It was un-spoilered. Allow it only if a human moderator did it.
      let byMod = false;
      try {
        const log = await reddit
          .getModerationLog({ subredditName: context.subredditName!, type: 'unspoiler', limit: 50 })
          .all();
        byMod = log.some((a) => a.target?.id === postId && a.moderatorName !== context.appSlug);
      } catch (err) {
        console.error('[spoiler] mod-log lookup failed:', err);
      }
      if (!byMod) {
        await post.markAsSpoiler();
        console.log(`[r/${context.subredditName}] re-spoilered ${postId} (no mod log entry)`);
      }
    }
  }
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Moderator removed an original  ->  flag its hash (old shared_mod_log_monitor)
// ===========================================================================
triggers.post('/on-mod-action', async (c) => {
  const input = await c.req.json<OnModActionRequest>();
  const modName = input.moderator?.name;
  const targetId = input.targetPost?.id;
  if (input.action === 'removelink' && targetId && modName && modName !== context.appSlug) {
    await callService('/mod-removed', {
      subreddit: context.subredditName,
      submission_id: bareId(targetId),
    });
  }
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Post deleted by its author  ->  purge from index (old shared_removal_checker)
// ===========================================================================
triggers.post('/on-post-delete', async (c) => {
  const input = await c.req.json<OnPostDeleteRequest>();
  const rawId = input.postId;
  if (rawId) {
    await callService('/delete', {
      subreddit: context.subredditName,
      submission_id: bareId(rawId),
    });
  }
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Backfill recent posts on install/upgrade  (old per-subreddit initial scan)
// ===========================================================================
async function backfill(): Promise<void> {
  if (!(await getBool('backfillOnInstall', true))) return;
  if (!(await getBool('enableDuplicateDetection', true))) return;
  try {
    const posts = await reddit
      .getNewPosts({ subredditName: context.subredditName!, limit: 25 })
      .all();
    let indexed = 0;
    for (const post of posts) {
      if (!isImageUrl(post.url)) continue;
      const r = await callService('/index', {
        subreddit: context.subredditName,
        submission_id: bareId(post.id),
        url: post.url,
        created_utc: Math.floor(post.createdAt.getTime() / 1000),
        author: post.authorName,
        title: post.title,
        permalink: post.permalink,
      });
      if (r?.indexed) indexed++;
    }
    console.log(`[r/${context.subredditName}] backfill indexed ${indexed} images`);
  } catch (err) {
    console.error('[backfill] failed:', err);
  }
}

triggers.post('/on-app-install', async (c) => {
  const _input = await c.req.json<OnAppInstallRequest>();
  await backfill();
  return c.json<TriggerResponse>(okTrigger, 200);
});
triggers.post('/on-app-upgrade', async (c) => {
  await backfill();
  return c.json<TriggerResponse>(okTrigger, 200);
});

// ===========================================================================
// Scheduler: fire the 1-hour single-report auto-approve
// ===========================================================================
schedulerRoutes.post('/auto-approve', async (c) => {
  const input = await c.req.json<TaskRequest>();
  const postId = (input.data as { postId?: string } | undefined)?.postId;
  if (postId) {
    const post = await reddit.getPostById(t3(postId));
    if (!post.removed && !post.approved && (post.numberOfReports ?? 0) === 1) {
      await post.approve();
      console.log(`[r/${context.subredditName}] auto-approved single-report post ${postId}`);
    }
    await redis.del(`autoapprove:job:${t3(postId)}`);
  }
  return c.json({}, 200);
});

// ===========================================================================
// Settings validation for the thresholds JSON
// ===========================================================================
settingsRoutes.post('/validate-thresholds', async (c) => {
  const { value } = await c.req.json<SettingsValidationRequest<string>>();
  if (!value || !value.trim()) return c.json<SettingsValidationResponse>({ success: true });
  try {
    const parsed = JSON.parse(value);
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
      return c.json<SettingsValidationResponse>({
        success: false,
        error: 'Must be a JSON object keyed by report reason.',
      });
    }
    for (const [reason, rules] of Object.entries(parsed)) {
      if (typeof rules !== 'object' || rules === null) {
        return c.json<SettingsValidationResponse>({
          success: false,
          error: `"${reason}" must map to an object of thresholds.`,
        });
      }
      for (const [k, v] of Object.entries(rules as Record<string, unknown>)) {
        if (!['postRemove', 'postApprove', 'commentRemove', 'commentApprove'].includes(k)) {
          return c.json<SettingsValidationResponse>({
            success: false,
            error: `Unknown key "${k}" under "${reason}".`,
          });
        }
        if (typeof v !== 'number' || v < 0 || !Number.isInteger(v)) {
          return c.json<SettingsValidationResponse>({
            success: false,
            error: `"${reason}.${k}" must be a non-negative integer.`,
          });
        }
      }
    }
    return c.json<SettingsValidationResponse>({ success: true });
  } catch {
    return c.json<SettingsValidationResponse>({ success: false, error: 'Invalid JSON.' });
  }
});

// ---------------------------------------------------------------------------
// Mount and serve
// ---------------------------------------------------------------------------
internal.route('/triggers', triggers);
internal.route('/scheduler', schedulerRoutes);
internal.route('/settings', settingsRoutes);
app.route('/internal', internal);

serve({
  fetch: app.fetch,
  createServer,
  port: getServerPort(),
});
